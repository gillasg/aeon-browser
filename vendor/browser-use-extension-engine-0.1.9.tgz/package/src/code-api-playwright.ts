// Playwright-compatible names on top of the browser_code API. Models reach for Playwright by
// habit (page.title(), page.goto(), locator.innerText(), page.$$eval...), so those calls work as
// a Playwright user expects instead of failing and costing a model turn. Reads run in the page;
// actions reuse the engine's own click/fill/press so they keep its waiting and verification.
export const browserPlaywrightApi = `
// A string that can also be called, so page.url and page.url() both work.
function __callableString(read, call) {
  var fn = call || (() => read());
  return new Proxy(fn, {
    get(_, key) {
      var value = read() || '';
      if (key === Symbol.toPrimitive || key === 'toString' || key === 'valueOf' || key === 'toJSON') return () => value;
      if (key === Symbol.for('nodejs.util.inspect.custom')) return () => value;
      var member = value[key];
      return typeof member === 'function' ? member.bind(value) : member;
    },
  });
}
// Resolves a locator spec to elements inside the page (runs page-side, so it must be self-contained).
function __resolveInPage(spec) {
  var roots = spec.scope ? [...document.querySelectorAll(spec.scope)] : [document];
  var all = (selector) => roots.flatMap((root) => [...root.querySelectorAll(selector)]);
  var text = (el) => (el.innerText || el.textContent || '').replace(/\\s+/g, ' ').trim();
  var pattern = spec.regex ? new RegExp(spec.regex[0], spec.regex[1]) : null;
  var match = (value) => pattern ? pattern.test(value) : spec.exact ? value === spec.value : value.toLowerCase().includes(String(spec.value).toLowerCase());
  var found;
  if (spec.by === 'css') found = all(spec.value);
  else if (spec.by === 'text') found = all('body *').filter((el) => match(text(el)) && ![...el.children].some((child) => match(text(child))));
  else if (spec.by === 'label') found = all('input,textarea,select,[contenteditable]').filter((el) => [...(el.labels || [])].some((label) => match(text(label))) || match(el.getAttribute('aria-label') || ''));
  else if (spec.by === 'placeholder') found = all('[placeholder]').filter((el) => match(el.getAttribute('placeholder') || ''));
  else {
    var roles = {button:'button,[role=button],input[type=button],input[type=submit]', link:'a[href],[role=link]',
      textbox:'input:not([type]),input[type=text],input[type=search],input[type=email],input[type=tel],input[type=url],input[type=number],input[type=password],textarea,[role=textbox],[role=searchbox]',
      searchbox:'input[type=search],[role=searchbox]', heading:'h1,h2,h3,h4,h5,h6,[role=heading]', checkbox:'input[type=checkbox],[role=checkbox]',
      radio:'input[type=radio],[role=radio]', combobox:'select,[role=combobox]', option:'option,[role=option]', img:'img,[role=img]',
      listitem:'li,[role=listitem]', list:'ul,ol,[role=list]', row:'tr,[role=row]', cell:'td,[role=cell]', table:'table,[role=table]', tab:'[role=tab]', menuitem:'[role=menuitem]', dialog:'dialog,[role=dialog]'};
    found = all(roles[spec.role] || '[role="' + spec.role + '"]');
    var name = (el) => (el.getAttribute('aria-label') || text(el) || el.value || el.alt || el.title || '').replace(/\\s+/g, ' ').trim();
    if (pattern) found = found.filter((el) => pattern.test(name(el)));
    else if (spec.name) found = found.filter((el) => spec.exact ? name(el) === spec.name : name(el).toLowerCase().includes(spec.name.toLowerCase()));
  }
  if (spec.hasText) found = found.filter((el) => text(el).toLowerCase().includes(String(spec.hasText).toLowerCase()));
  return found;
}
function __spec(element) {
  if (element.kind === 'locator') return {role: element.role, name: element.name, exact: element.exact, scope: element.scope, hasText: element.hasText, regex: element.regex};
  return {by: element.by, value: element.value, exact: element.exact, scope: element.scope, hasText: element.hasText, regex: element.regex};
}
// Runs a read on the matched elements in the page: op receives (elements, arg). The expression is
// assembled as source, not eval'd in the page, so strict Content-Security-Policy pages allow it.
function __locatorRead(target, element, index, op, arg) {
  var expression = '(() => { var found = (' + __resolveInPage.toString() + ')(' + JSON.stringify(__spec(element)) + ');' +
    (index === undefined ? '' : ' var index = ' + Number(index) + '; found = index < 0 ? found.slice(index).slice(0, 1) : found.slice(index, index + 1);') +
    ' return (' + op.toString() + ')(found, ' + (arg === undefined ? 'undefined' : JSON.stringify(arg)) + '); })()';
  return browser.page(target).inspect(expression);
}
function __single(found) { if (!found.length) throw new Error('TARGET_NOT_FOUND: no element matches'); return found[0]; }
// An indexed locator (nth/first/last) cannot use the engine's unique-match targeting, so it is
// clicked at the element's centre after scrolling it into view.
async function __clickIndexed(target, element, index, options) {
  var box = await __locatorRead(target, element, index, (found) => {
    var el = found[0];
    if (!el) throw new Error('TARGET_NOT_FOUND: no element matches');
    el.scrollIntoView({block: 'center', inline: 'center'});
    var rect = el.getBoundingClientRect();
    return {x: rect.left + rect.width / 2, y: rect.top + rect.height / 2};
  });
  var page = browser.page(target);
  return options && options.clickCount === 2 ? page.doubleClickAt(box.x, box.y) : page.clickAt(box.x, box.y);
}
function __extendLocator(target, element, base, index) {
  var self = () => __locator(target, element, index);
  var read = (op, arg) => __locatorRead(target, element, index, op, arg);
  var indexed = index !== undefined;
  var at = (i) => __locator(target, element, i);
  return Object.assign(base, {
    first: () => at(0), last: () => at(-1), nth: (i) => at(i),
    all: async () => Array.from({length: await read((found) => found.length)}, (_, i) => at(i)),
    count: () => read((found) => found.length),
    filter: (options = {}) => __locator(target, {...element, ...(options.hasText ? {hasText: options.hasText} : {})}, index),
    innerText: () => read((found) => found.length ? found[0].innerText : (() => { throw new Error('TARGET_NOT_FOUND: no element matches'); })()),
    textContent: () => read((found) => found.length ? found[0].textContent : null),
    innerHTML: () => read((found) => found.length ? found[0].innerHTML : ''),
    inputValue: () => read((found) => found.length ? found[0].value : ''),
    getAttribute: (name) => read((found, name) => found.length ? found[0].getAttribute(name) : null, name),
    isVisible: () => read((found) => found.some((el) => { var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== 'hidden'; })),
    isChecked: () => read((found) => Boolean(found[0] && found[0].checked)),
    allInnerTexts: () => read((found) => found.map((el) => el.innerText)),
    allTextContents: () => read((found) => found.map((el) => el.textContent || '')),
    evaluate: (fn, arg) => read('(found, arg) => (' + fn.toString() + ')(found[0], arg)', arg),
    evaluateAll: (fn, arg) => read('(found, arg) => (' + fn.toString() + ')(found, arg)', arg),
    waitFor: (options = {}) => __waitUntil(() => read((found) => found.length), options.timeout ?? 10000),
    ...(indexed ? {
      click: (options) => __clickIndexed(target, element, index, options),
      dblclick: () => __clickIndexed(target, element, index, {clickCount: 2}),
      fill: async (value) => { await __clickIndexed(target, element, index); await browser.page(target).keyboard('ControlOrMeta+a'); return browser.page(target).cdp('Input.insertText', {text: String(value)}); },
    } : {
      dblclick: async () => __clickIndexed(target, element, 0, {clickCount: 2}),
    }),
    type: (value) => self().fill(value),
    pressSequentially: (value) => self().fill(value),
    selectOption: (value) => self().fill(Array.isArray(value) ? value[0] : (value && value.label) || (value && value.value) || value),
    check: async () => { if (!(await self().isChecked())) await self().click(); },
    uncheck: async () => { if (await self().isChecked()) await self().click(); },
    hover: async () => { var b = await read((found) => { var r = __single(found).getBoundingClientRect(); return {x: r.left + r.width / 2, y: r.top + r.height / 2}; }); return browser.page(target).hover(b.x, b.y); },
    scrollIntoViewIfNeeded: () => read((found) => { if (found[0]) found[0].scrollIntoView({block: 'center'}); return true; }),
  });
}
// Page-side: rows of the first matching table (or role=table grid) keyed by header text.
function __readTable(selector, options) {
  var table = document.querySelector(selector);
  if (!table) throw new Error('TARGET_NOT_FOUND: no table matches ' + selector);
  var clean = (el) => (el.innerText || el.textContent || '').replace(/\\s+/g, ' ').trim();
  var rows = [...table.querySelectorAll('tr,[role=row]')].map((row) => [...row.querySelectorAll('th,td,[role=cell],[role=columnheader],[role=gridcell]')].map(clean));
  rows = rows.filter((cells) => cells.some(Boolean));
  if (!rows.length) return [];
  var headers = rows[0].map((cell, i) => cell || 'column' + (i + 1));
  var body = rows.slice(1, 1 + (options.limit || 500));
  return options.raw ? rows.slice(0, 1 + (options.limit || 500)) : body.map((cells) => Object.fromEntries(headers.map((h, i) => [h, cells[i] ?? ''])));
}
function __readLinks(selector) {
  var root = document.querySelector(selector) || document.body;
  return [...root.querySelectorAll('a[href]')].slice(0, 500).map((a) => ({text: (a.innerText || a.getAttribute('aria-label') || '').replace(/\\s+/g, ' ').trim().slice(0, 200), href: a.href}));
}
// google.search: real Google results through the user's browser (their region and language),
// parsed into {title, url, source, snippet}. Run queries one after another, never in parallel.
var google = Object.freeze({
  search: async (query, options = {}) => {
    var page = await __call({google: 'search', query, ...options});
    return __parseGoogle(page.html, options.limit ?? 10);
  },
});
function __parseGoogle(html, limit) {
  var doc = new DOMParser().parseFromString(html, 'text/html');
  var clean = (text) => (text || '').replace(/\\s+/g, ' ').trim();
  var seen = new Set(), results = [];
  for (var heading of doc.querySelectorAll('a[href] h3, h3 a[href]')) {
    var link = heading.closest('a[href]') || heading.querySelector('a[href]');
    var href = link && link.getAttribute('href') || '';
    if (href.startsWith('/url?')) href = new URL(href, 'https://www.google.com').searchParams.get('q') || '';
    if (!/^https?:/.test(href) || /^https?:\\/\\/([a-z]+\\.)?google\\./.test(href) || seen.has(href)) continue;
    seen.add(href);
    var block = link.closest('[data-rpos], [data-hveid], .g') || link.parentElement;
    var title = clean(heading.textContent);
    var snippet = clean(block && block.textContent).replace(title, '').slice(0, 400);
    var source = (() => { try { return new URL(href).hostname.replace(/^www\\./, ''); } catch { return ''; } })();
    results.push({title, url: href, source, snippet});
    if (results.length >= limit) break;
  }
  if (!results.length && /unusual traffic|detected unusual|captcha/i.test(html))
    throw new Error('GOOGLE_BLOCKED: Google asked for a check. Use the websearch tool, or open the results in a tab.');
  return results;
}
async function __waitUntil(check, timeout) {
  var deadline = Date.now() + timeout;
  while (Date.now() < deadline) { if (await check()) return; await new Promise((done) => setTimeout(done, 250)); }
  throw new Error('TIMEOUT: element did not appear');
}
function __extendPage(target, base) {
  var css = (selector) => base.locator(selector);
  var keys = base.keyboard;
  var keyboard = Object.assign((combo) => keys(combo), {
    press: (combo) => keys(combo),
    type: (text) => base.cdp('Input.insertText', {text: String(text)}),
    insertText: (text) => base.cdp('Input.insertText', {text: String(text)}),
  });
  var byRole = base.getByRole, byText = base.getByText;
  return Object.assign(base, {
    // Playwright accepts a RegExp for names and text. The engine's own targeting matches strings,
    // so a regex locator resolves in the page and acts on its first match.
    getByRole: (role, options = {}) => options.name instanceof RegExp
      ? __locator(target, {kind: 'locator', role, regex: [options.name.source, options.name.flags]}, 0)
      : byRole(role, options),
    getByText: (value, options = {}) => value instanceof RegExp
      ? __locator(target, {kind: 'query', by: 'text', regex: [value.source, value.flags]}, 0)
      : byText(value, options),
    // Playwright-style text snapshot of the page: the same view as bu.state().
    ariaSnapshot: (options = {}) => bu.state({...options, target}),
    goto: (url) => base.navigate(url),
    reload: () => base.cdp('Page.reload', {}),
    goBack: () => base.evaluate(() => history.back()),
    goForward: () => base.evaluate(() => history.forward()),
    content: () => base.evaluate(() => document.documentElement.outerHTML),
    $: (selector) => css(selector).first(),
    $$: (selector) => css(selector).all(),
    $eval: (selector, fn, arg) => css(selector).first().evaluate(fn, arg),
    $$eval: (selector, fn, arg) => css(selector).evaluateAll(fn, arg),
    textContent: (selector) => css(selector).first().textContent(),
    innerText: (selector) => css(selector).first().innerText(),
    getAttribute: (selector, name) => css(selector).first().getAttribute(name),
    inputValue: (selector) => css(selector).first().inputValue(),
    isVisible: (selector) => css(selector).isVisible(),
    hoverSelector: (selector) => css(selector).first().hover(),
    waitForSelector: (selector, options = {}) => base.wait(selector, {timeoutMs: options.timeout ?? 10000}).then(() => css(selector).first()),
    waitForLoadState: (_state, options = {}) => base.waitFor(() => document.readyState === 'complete', {timeoutMs: options.timeout ?? 15000}),
    waitForURL: (pattern, options = {}) => __waitUntil(async () => {
      var url = await base.evaluate(() => location.href);
      return pattern instanceof RegExp ? pattern.test(url) : String(url).includes(String(pattern).replace(/\\*\\*/g, ''));
    }, options.timeout ?? 15000),
    waitForTimeout: (ms) => new Promise((done) => setTimeout(done, Math.min(ms, 30000))),
    // Extraction: a table as rows keyed by its header cells, and links with their text.
    table: (selector = 'table', options = {}) => base.inspect('(' + __readTable.toString() + ')(' + JSON.stringify(selector) + ', ' + JSON.stringify(options) + ')'),
    links: (selector = 'body') => base.inspect('(' + __readLinks.toString() + ')(' + JSON.stringify(selector) + ')'),
    keyboard,
    mouse: Object.freeze({
      click: (x, y, options = {}) => options.clickCount === 2 ? base.doubleClickAt(x, y) : base.clickAt(x, y),
      dblclick: (x, y) => base.doubleClickAt(x, y),
      move: (x, y) => base.hover(x, y),
      wheel: (_dx, dy) => base.scroll(dy >= 0 ? 'down' : 'up', Math.abs(dy) || 600),
    }),
  });
}
`;
